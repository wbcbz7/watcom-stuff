#include <math.h>

#define fxshort long;
#define fxchar  short;

int main() {

}