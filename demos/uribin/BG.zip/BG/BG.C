#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include <memory.h>
#include "rtctimer.h"
#include "..\flexptc\flexptc.c"

#define X_SIZE 640
#define Y_SIZE 350
#define sat(a, l) ((a > l) ? l : a)
#define ee 1.0E-6

unsigned char  *screen = (unsigned char*)0xA0000;
ptc_palette    pal[256];

unsigned char  buffer[X_SIZE * Y_SIZE], buffer2[X_SIZE * Y_SIZE];
unsigned char  blendtab[65536];

// background sprite info
#define SPR_SIZE 16
#define X_GRID   (X_SIZE / SPR_SIZE)
#define Y_GRID   (Y_SIZE / SPR_SIZE)
 
unsigned char  bgspr [SPR_SIZE * SPR_SIZE];
unsigned long  bggrid[X_GRID * Y_GRID];

         short sintab[65536];

double pi = 3.141592653589793;

void initpal() {  
    int i;
    
    pal[0].r = pal[0].g = pal[0].b = 0;
    for (i = 1; i < 256; i++) {
        pal[i].r = sat(4  + (i >> 2) + (i >> 4), 63);
        pal[i].g = sat(12 + (i >> 1) - (i >> 4), 63); 
        pal[i].b = sat(6  + (i >> 3) + (i >> 3), 63);
    }
}

void initbg() {
    int x, y, k=0;
    
    for (y = -(SPR_SIZE / 2); y < (SPR_SIZE / 2); y++) {
        for (x = -(SPR_SIZE / 2); x < (SPR_SIZE / 2); x++) {
            bgspr[k++] = (((0x200 * SPR_SIZE) / (x*x + y*y + ee)) <= (0x10 * SPR_SIZE) ? 0 : 0xFF);
            //bgspr[k++] = sat((0x8000 / (x*x + y*y + ee)), 255);
        }
    }
}

void initsintab() {
    int i, j;
    double r, lut_mul;
    lut_mul = (2 * pi / 65536);
    for (i = 0; i < 65536; i++) {
        r = i * lut_mul;
        sintab[i] = 32767 * sin(r);
    }
}

void adjustbuf() {
    int x, y, i, k=0;
    
    for (y = 0; y < Y_GRID; y++) {
        for (x = 0; x < X_GRID; x++) {
            bggrid[k] = (bggrid[k] <= 0x02020202 ? 0x02020202 : bggrid[k] - 0x01010101);
            k++;
        }
    }

    // draw random grid nodes
    for (i = 0; i < 40; i++) {
        k = (rand() % (Y_GRID * X_GRID));
        bggrid[k] = ((rand() & 0x1F) + 8) * 0x01010101;
    }
}

void drawbuf(int i) {
    unsigned int  k=0, c, l, x, y,col;
    unsigned char *buf = &buffer;
    unsigned char *spr = &bgspr;
    
    
    // fill upper gap
    _asm {
        cld
        mov    eax, 0x01010101
        mov    ecx, (X_SIZE * (Y_SIZE - (SPR_SIZE * (Y_SIZE / SPR_SIZE)))) / 8
        mov    edi, buf
        rep    stosd
    }
    
    // adjust pointer
    buf += (X_SIZE * (Y_SIZE - (SPR_SIZE * (Y_SIZE / SPR_SIZE)))) / 2;
    
    // draw background sprites (tiles in fact ;)
    for (y = 0; y < Y_GRID; y++) {
        for (x = 0; x < X_GRID; x++) {
            col = bggrid[k++];
            spr = &bgspr;
            /*
            _asm {
                cld
                mov    esi, spr
                mov    edi, buf
                mov    ebx, SPR_SIZE
                
                @y_loop:
                mov    ecx, (SPR_SIZE / 4)
                rep    movsd
                
                add    edi, (X_SIZE - SPR_SIZE);
                dec    ebx
                jnz    @y_loop
            }
            */
            _asm {
                cld
                mov    edx, col
                mov    esi, spr
                mov    edi, buf
                mov    ebx, SPR_SIZE
                
                @y_loop:
                mov    ecx, (SPR_SIZE / 4)
                
                @x_loop:
                mov    eax, [esi]
                and    eax, edx
                add    esi, 4
                add    eax, 0x01010101
                mov    [edi], eax
                add    edi, 4
                dec    ecx
                jnz    @x_loop
                
                add    edi, (X_SIZE - SPR_SIZE);
                dec    ebx
                jnz    @y_loop
            }
            buf += SPR_SIZE;
        }
        buf += (X_SIZE * (SPR_SIZE-1));
    }
    
    // fill lower gap
    _asm {
        cld
        mov    eax, 0x01010101
        mov    ecx, (X_SIZE * (Y_SIZE - (SPR_SIZE * (Y_SIZE / SPR_SIZE)))) / 8
        mov    edi, buf
        rep    stosd
    }
    
    
    // fill random buffer lines
    for (k = 0; k < 40; k++) {
        c = (rand() & 0xF) * 0x01010101;
        l = ((rand() % (Y_SIZE - 1)) * X_SIZE);
        buf = &buffer[l];
        _asm {
            cld
            mov    eax, c
            mov    ecx, (X_SIZE / 4)
            mov    edi, buf
            
            @loop:
            add    [edi], eax
            add    edi, 4
            dec    ecx
            jnz    @loop            
        }
    }
}

void blend();
#pragma aux blend = " mov   esi, offset blendtab  " \
                    " mov   ebx, offset buffer    " \
                    " mov   edi, offset buffer2   " \
                    " mov   ecx, 224000" \
                    " xor   edx, edx              " \
                    " nop                         " \
                    " @inner:                     " \
                    " mov   dh,    [ebx]          " \
                    " mov   dl,    [edi]          " \
                    " inc   ebx                   " \
                    " mov   al,    [esi + edx]    " \
                    " mov   [edi], al             " \
                    " inc   edi                   " \
                    " dec   ecx                   " \
                    " jnz   @inner                " \
                    modify [esi edi ebx ecx edx];

volatile int tick = 0;
void timer() { tick++;}

int main() {
    int i, j, p = 0;
    int atick;
    
    srand(inp(0x40));
    initsintab();
    initpal();
    initbg();
 
    if (ptc_open("", X_SIZE, Y_SIZE, 8, 0)) {return 0;}
    
    if (X_SIZE == 320) {
        _asm {    
            // zpizzheno ;)
            mov dx,3d4h   // remove protection
            mov al,11h
            out dx,al
            inc dl
            in  al,dx
            and al,7fh
            out dx,al

            mov dx,3c2h   // misc output
            mov al,0e3h   // clock
            out dx,al

            mov dx,3d4h
            mov ax,00B06h // Vertical Total
            out dx,ax
            mov ax,03E07h // Overflow
            out dx,ax
            mov ax,0C310h // Vertical start retrace
            out dx,ax
            mov ax,08C11h // Vertical end retrace
            out dx,ax
            mov ax,08F12h // Vertical display enable end
            out dx,ax
            mov ax,09015h // Vertical blank start
            out dx,ax
            mov ax,00B16h // Vertical blank end
            out dx,ax
        }
    }
    
    for (j = 1; j < 256; j++) for (i = 1; i < 256; i++) blendtab[p++] = sat(((i * 128) >> 8) + ((j * 128) >> 8), 255);
    
    ptc_setpal(&pal[0]);
    
    rtc_initTimer(3);
    rtc_setTimer(&timer, rtc_timerRate / 60);

    while (!kbhit()) {
        i = tick;
        ptc_wait();

        //outp(0x3C8, 0); outp(0x3C9, 63); outp(0x3C9, 0); outp(0x3C9, 0);
        
        ptc_update(&buffer);
        adjustbuf();
        drawbuf(i);
        //blend();
        //outp(0x3C8, 0); outp(0x3C9, 0); outp(0x3C9, 0); outp(0x3C9, 0); 
    }
    
    getch();
    ptc_close();
    rtc_freeTimer();
    _asm {
        mov  ax, 3
        int  10h
    }
}
