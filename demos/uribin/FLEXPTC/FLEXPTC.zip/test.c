#include "flexptc.c"

#define X_SIZE 640
#define Y_SIZE 350

unsigned long buffer[X_SIZE * Y_SIZE];

int main() {
    int i=0;
    
    ptc_open("", X_SIZE, Y_SIZE, 8, ptc_OPEN_FORCEBANKED);
    while (!kbhit()) {
        i++;
        ptc_wait();
        printf("%d ", i);
    }; getch();
    ptc_close();
}