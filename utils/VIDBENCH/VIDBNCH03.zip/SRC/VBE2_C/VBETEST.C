    #include "vesavbe.h"
    #include <math.h>
    #include <stdlib.h>
    #include <stdio.h>
    #include <conio.h>

    void error (char *msg)
    {
      printf ("Error: %s\n", msg);
      exit(1);
    }

    void Test_8Bit (void)
    {
      // Test 8-bit modes:
      int mode;
      VBE_ModeInfoBlock ModeInfo;
      int x;
      int y;
      char *VIDEO;

      mode = VBE_FindMode (640,480,8);
      if ( mode==-1 ) error( "640x480x8 not found");
      if ( !VBE_IsModeLinear(mode)) error ("Mode is not linear");

      // Set the video-mode
      VBE_SetMode (mode, 1, 1);
      // Get a pointer to the linear screen-memory
      VIDEO = VBE_GetVideoPtr (mode);

      // this should never occur if you test the linearity!
      if ( !VIDEO ) error ("LFB invalid");

      // We also need the ModeInformationBlock!

      VBE_Mode_Information (mode, &ModeInfo);


      for ( y=0; y<ModeInfo.YResolution; y++ )
      for ( x=0; x<ModeInfo.XResolution; x++ )
        VIDEO[ModeInfo.BytesPerScanline*y+x]=x^y;
    }

    void Test_16Bit (void)
    {
      int mode;
      int x, y, i;
      VBE_ModeInfoBlock ModeInfo;
      short rtab[256];
      short gtab[256];
      short btab[256];
      short *VIDEO;

      // Test 16-bit modes:
      mode = VBE_FindMode (640,480,16);
      if ( mode==-1 ) error( "640x480x16 not found");
      if ( !VBE_IsModeLinear(mode)) error ("Mode is not linear");

      // Set the video-mode
      VBE_SetMode (mode, 1, 1);
      // Get a pointer to the linear screen-memory
      VIDEO = (short *) VBE_GetVideoPtr (mode);

      // this should never occur if you test the linearity!
      if ( !VIDEO ) error ("LFB invalid");

      // We also need the ModeInformationBlock!

      VBE_Mode_Information (mode, &ModeInfo);

      // Calculate Pseudo Color Lookup-Tables
      for ( i=0; i<256; i++ ) {
        rtab[i]=(i>>(8-ModeInfo.RedMaskSize))<<ModeInfo.RedFieldPosition;
        gtab[i]=(i>>(8-ModeInfo.GreenMaskSize))<<ModeInfo.GreenFieldPosition;
        btab[i]=(i>>(8-ModeInfo.BlueMaskSize))<<ModeInfo.BlueFieldPosition;
      }

      for ( y=0; y<ModeInfo.YResolution; y++ )
      for ( x=0; x<ModeInfo.XResolution; x++ )
      {
        char r =(float)(127.0+127.0*sin((float)x/10.0));
        char g =(float)(127.0+127.0*sin((float)y/10.0));
        char b =(float)(127.0+127.0*cos((float)(x+y)/10.0));
        VIDEO[((ModeInfo.BytesPerScanline)/2*y+x)]=(rtab[r]|btab[b]|gtab[g]);
      }
      getch();

      // Set TextMode
      VBE_SetMode (3, 0, 1);
    }

    void main (void)
    {
      // VESA VBE 2.0 Interface test
      VBE_Init();

      Test_8Bit ();
      getch();
      Test_16Bit ();
      VBE_SetMode (3, 0, 1);
      VBE_Done();
    }